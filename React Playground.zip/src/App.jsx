import React from 'react';
import { TodoWrapper } from './components/TodoWrapper';

export function App(props) {
  return (
    <div className='App'>
      <TodoWrapper />
    </div>
  );
}

// Log to console
console.log('Hello console');
